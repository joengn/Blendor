export function browserStorage(key, storage = globalThis.localStorage) {
  return {
    read() {
      const value = storage.getItem(key);
      return value ? JSON.parse(value) : null;
    },
    write(state) {
      storage.setItem(key, JSON.stringify(state));
    },
  };
}
