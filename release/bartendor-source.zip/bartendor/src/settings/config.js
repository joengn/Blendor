export const APP_SETTINGS = Object.freeze({
  storageKey: 'bartendor-game',
  defaultPlayerNames: Object.freeze(['Player 1', 'Player 2']),
  mode: 'local',
});
